import "@sass-palette/hope-inject";
export default {};
