import clientConfig0 from 'D:/vuepress-starter/hblog/src/.vuepress/.temp/sass-palette/load-hope.js'
import clientConfig1 from 'D:/vuepress-starter/hblog/src/.vuepress/.temp/components/config.js'
import clientConfig2 from 'D:/vuepress-starter/hblog/node_modules/@vuepress/plugin-active-header-links/lib/client/config.js'
import clientConfig3 from 'D:/vuepress-starter/hblog/node_modules/vuepress-plugin-auto-catalog/lib/client/config.js'
import clientConfig4 from 'D:/vuepress-starter/hblog/node_modules/@vuepress/plugin-external-link-icon/lib/client/config.js'
import clientConfig5 from 'D:/vuepress-starter/hblog/node_modules/@vuepress/plugin-nprogress/lib/client/config.js'
import clientConfig6 from 'D:/vuepress-starter/hblog/node_modules/@vuepress/plugin-theme-data/lib/client/config.js'
import clientConfig7 from 'D:/vuepress-starter/hblog/node_modules/vuepress-plugin-comment2/lib/client/config.js'
import clientConfig8 from 'D:/vuepress-starter/hblog/node_modules/vuepress-plugin-copy-code2/lib/client/config.js'
import clientConfig9 from 'D:/vuepress-starter/hblog/src/.vuepress/.temp/md-enhance/config.js'
import clientConfig10 from 'D:/vuepress-starter/hblog/node_modules/vuepress-plugin-photo-swipe/lib/client/config.js'
import clientConfig11 from 'D:/vuepress-starter/hblog/src/.vuepress/.temp/theme-hope/config.js'

export const clientConfigs = [
  clientConfig0,
  clientConfig1,
  clientConfig2,
  clientConfig3,
  clientConfig4,
  clientConfig5,
  clientConfig6,
  clientConfig7,
  clientConfig8,
  clientConfig9,
  clientConfig10,
  clientConfig11,
]
