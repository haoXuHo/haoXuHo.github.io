export const data = JSON.parse("{\"key\":\"v-aa47d568\",\"path\":\"/tag/%E7%BD%91%E5%9D%80/\",\"title\":\"网址 Tag\",\"lang\":\"en-US\",\"frontmatter\":{\"title\":\"网址 Tag\",\"feed\":false,\"sitemap\":false,\"blog\":{\"type\":\"category\",\"name\":\"网址\",\"key\":\"tag\"},\"layout\":\"BlogCategory\",\"description\":\"\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/tag/%E7%BD%91%E5%9D%80/\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"网址 Tag\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"website\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"en-US\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"WebPage\\\",\\\"name\\\":\\\"网址 Tag\\\"}\"]]},\"headers\":[],\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
