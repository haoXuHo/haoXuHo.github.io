export const data = JSON.parse("{\"key\":\"v-07b153f3\",\"path\":\"/tag/%E6%88%91%E7%9A%84%E5%8D%9A%E5%AE%A2/\",\"title\":\"我的博客 Tag\",\"lang\":\"en-US\",\"frontmatter\":{\"title\":\"我的博客 Tag\",\"feed\":false,\"sitemap\":false,\"blog\":{\"type\":\"category\",\"name\":\"我的博客\",\"key\":\"tag\"},\"layout\":\"BlogCategory\",\"description\":\"\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/tag/%E6%88%91%E7%9A%84%E5%8D%9A%E5%AE%A2/\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"我的博客 Tag\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"website\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"en-US\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"WebPage\\\",\\\"name\\\":\\\"我的博客 Tag\\\"}\"]]},\"headers\":[],\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
