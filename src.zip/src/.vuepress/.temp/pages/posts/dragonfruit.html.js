export const data = JSON.parse("{\"key\":\"v-24b7c48d\",\"path\":\"/posts/dragonfruit.html\",\"title\":\"宝藏up主\",\"lang\":\"zh-CN\",\"frontmatter\":{\"icon\":\"edit\",\"date\":\"2023-04-17T00:00:00.000Z\",\"category\":[\"宝藏up主\"],\"description\":\"宝藏up主 看风景当然就links啦 链接放这啦 #LINKS# ！ ！ ！ ！\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/posts/dragonfruit.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小组博客演示\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"宝藏up主\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"宝藏up主 看风景当然就links啦 链接放这啦 #LINKS# ！ ！ ！ ！\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"meta\",{\"property\":\"article:author\",\"content\":\"teamwork\"}],[\"meta\",{\"property\":\"article:published_time\",\"content\":\"2023-04-17T00:00:00.000Z\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"宝藏up主\\\",\\\"image\\\":[\\\"\\\"],\\\"datePublished\\\":\\\"2023-04-17T00:00:00.000Z\\\",\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"teamwork\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"看风景当然就links啦\",\"slug\":\"看风景当然就links啦\",\"link\":\"#看风景当然就links啦\",\"children\":[]},{\"level\":2,\"title\":\"链接放这啦\",\"slug\":\"链接放这啦\",\"link\":\"#链接放这啦\",\"children\":[]}],\"readingTime\":{\"minutes\":0.18,\"words\":53},\"filePathRelative\":\"posts/dragonfruit.md\",\"localizedDate\":\"2023年4月17日\",\"excerpt\":\"<h1> 宝藏up主</h1>\\n<h2> 看风景当然就links啦</h2>\\n<p><img src=\\\"/links1.png\\\" alt=\\\"\\\" loading=\\\"lazy\\\">\\n<img src=\\\"/links22.png\\\" alt=\\\"\\\" loading=\\\"lazy\\\"></p>\\n<h2> 链接放这啦</h2>\\n<p><a href=\\\"https://space.bilibili.com/3816626\\\" target=\\\"_blank\\\" rel=\\\"noopener noreferrer\\\">#LINKS#</a></p>\\n<hr>\\n<p>！</p>\\n<p>！</p>\\n<p>！</p>\\n<p>！</p>\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
