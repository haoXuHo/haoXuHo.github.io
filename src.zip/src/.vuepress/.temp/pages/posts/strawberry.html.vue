<template><div><h1 id="看看风景" tabindex="-1"><a class="header-anchor" href="#看看风景" aria-hidden="true">#</a> 看看风景</h1>
<h2 id="冰岛" tabindex="-1"><a class="header-anchor" href="#冰岛" aria-hidden="true">#</a> 冰岛</h2>
<h3 id="" tabindex="-1"><a class="header-anchor" href="#" aria-hidden="true">#</a> </h3>
<figure><img src="/bin3.webp" alt="" tabindex="0" loading="lazy"><figcaption></figcaption></figure>
<p>冰岛是一个神秘而美丽的地方</p>
<p>从远处望去，仿佛是一块被时间遗忘的冰川巨石，在北极圈内，漫长的白夜和太阳的轨迹，是它独特的自然景观。</p>
<p>在这里，天空常年飘舞着缤纷绚烂的极光，如同色彩斑斓的帷幕，为这座冰岛添上了一份梦幻的色彩</p>
<h4 id="介绍" tabindex="-1"><a class="header-anchor" href="#介绍" aria-hidden="true">#</a> 介绍</h4>
<p>总得去一次吧</p>
<h3 id="不确定再看看" tabindex="-1"><a class="header-anchor" href="#不确定再看看" aria-hidden="true">#</a> 不确定再看看</h3>
<p><img src="/bin1.webp" alt="" loading="lazy">
<img src="/bin2.webp" alt="" loading="lazy">
<img src="/bin4.webp" alt="" loading="lazy"></p>
</div></template>


