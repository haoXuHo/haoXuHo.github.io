export const data = JSON.parse("{\"key\":\"v-3a333fc4\",\"path\":\"/posts/rzb1.md/1.html\",\"title\":\"思想\",\"lang\":\"zh-CN\",\"frontmatter\":{\"icon\":\"edit\",\"date\":\"2023-03-02T00:00:00.000Z\",\"category\":[\"深度学习概念\"],\"tag\":[\"有趣\",\"可读\",\"监督\"],\"description\":\"思想 深度学习的思想： 深度神经网络的基本思想是通过构建多层网络，对目标进行多层表示，以期通过多层的高层次特征来表示数据的抽象语义信息，获得更好的特征鲁棒性。 定义 深度学习定义：一般是指通过训练多层网络结构对未知数据进行分类或回归 分类 深度学习分类：有监督学习方法——深度前馈网络、卷积神经网络、循环神经网络等； 无监督学习方法——深度信念网、深度玻尔兹曼机，深度自编码器等。\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/posts/rzb1.md/1.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"博客演示\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"思想\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"思想 深度学习的思想： 深度神经网络的基本思想是通过构建多层网络，对目标进行多层表示，以期通过多层的高层次特征来表示数据的抽象语义信息，获得更好的特征鲁棒性。 定义 深度学习定义：一般是指通过训练多层网络结构对未知数据进行分类或回归 分类 深度学习分类：有监督学习方法——深度前馈网络、卷积神经网络、循环神经网络等； 无监督学习方法——深度信念网、深度玻尔兹曼机，深度自编码器等。\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"meta\",{\"property\":\"article:author\",\"content\":\"Eclipse\"}],[\"meta\",{\"property\":\"article:tag\",\"content\":\"有趣\"}],[\"meta\",{\"property\":\"article:tag\",\"content\":\"可读\"}],[\"meta\",{\"property\":\"article:tag\",\"content\":\"监督\"}],[\"meta\",{\"property\":\"article:published_time\",\"content\":\"2023-03-02T00:00:00.000Z\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"思想\\\",\\\"image\\\":[\\\"\\\"],\\\"datePublished\\\":\\\"2023-03-02T00:00:00.000Z\\\",\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"Eclipse\\\",\\\"url\\\":\\\"https://mrhope.site\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"定义\",\"slug\":\"定义\",\"link\":\"#定义\",\"children\":[{\"level\":3,\"title\":\"分类\",\"slug\":\"分类\",\"link\":\"#分类\",\"children\":[]}]}],\"readingTime\":{\"minutes\":0.62,\"words\":186},\"filePathRelative\":\"posts/rzb1.md/1.md\",\"localizedDate\":\"2023年3月2日\",\"excerpt\":\"<h1> 思想</h1>\\n<p>深度学习的思想：</p>\\n<p>深度神经网络的基本思想是通过构建多层网络，对目标进行多层表示，以期通过多层的高层次特征来表示数据的抽象语义信息，获得更好的特征鲁棒性。</p>\\n<h2> 定义</h2>\\n<p>深度学习定义：一般是指通过训练多层网络结构对未知数据进行分类或回归</p>\\n<h3> 分类</h3>\\n<p>深度学习分类：有监督学习方法——深度前馈网络、卷积神经网络、循环神经网络等；</p>\\n<pre><code>         无监督学习方法——深度信念网、深度玻尔兹曼机，深度自编码器等。\\n</code></pre>\\n\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
