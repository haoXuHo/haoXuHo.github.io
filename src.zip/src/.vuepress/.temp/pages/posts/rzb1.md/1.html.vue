<template><div><h1 id="思想" tabindex="-1"><a class="header-anchor" href="#思想" aria-hidden="true">#</a> 思想</h1>
<p>深度学习的思想：</p>
<p>深度神经网络的基本思想是通过构建多层网络，对目标进行多层表示，以期通过多层的高层次特征来表示数据的抽象语义信息，获得更好的特征鲁棒性。</p>
<h2 id="定义" tabindex="-1"><a class="header-anchor" href="#定义" aria-hidden="true">#</a> 定义</h2>
<p>深度学习定义：一般是指通过训练多层网络结构对未知数据进行分类或回归</p>
<h3 id="分类" tabindex="-1"><a class="header-anchor" href="#分类" aria-hidden="true">#</a> 分类</h3>
<p>深度学习分类：有监督学习方法——深度前馈网络、卷积神经网络、循环神经网络等；</p>
<pre><code>         无监督学习方法——深度信念网、深度玻尔兹曼机，深度自编码器等。
</code></pre>
</div></template>


