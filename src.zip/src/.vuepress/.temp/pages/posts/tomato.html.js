export const data = JSON.parse("{\"key\":\"v-df8b6e0c\",\"path\":\"/posts/tomato.html\",\"title\":\"黄楠的个人博客\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"黄楠的个人博客\",\"cover\":\"/assets/images/cover2.jpg\",\"icon\":\"edit\",\"date\":\"2023-04-18T00:00:00.000Z\",\"category\":[\"博客尝试\"],\"tag\":[\"个人\",\"网站\",\"试试看\"],\"star\":true,\"sticky\":true,\"copyright\":\"无版权\",\"comment\":false,\"sidebar\":false,\"description\":\"嗨，你好呀！ Heading 2 Here is the content. Heading 3 Here is the content.\"},\"headers\":[{\"level\":2,\"title\":\"Heading 2\",\"slug\":\"heading-2\",\"link\":\"#heading-2\",\"children\":[{\"level\":3,\"title\":\"Heading 3\",\"slug\":\"heading-3\",\"link\":\"#heading-3\",\"children\":[]}]}],\"readingTime\":{\"minutes\":0.19,\"words\":57},\"filePathRelative\":\"posts/tomato.md\",\"localizedDate\":\"2023年4月18日\",\"excerpt\":\"<h1> 嗨，你好呀！</h1>\\n<h2> Heading 2</h2>\\n<p>Here is the content.</p>\\n<h3> Heading 3</h3>\\n<p>Here is the content.</p>\\n\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
