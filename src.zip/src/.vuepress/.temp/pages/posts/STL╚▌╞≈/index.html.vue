<template><div><AutoCatalog>
  <template #icon="{ icon }">
    <HopeIcon :icon="icon" />
  </template>
</AutoCatalog>
</div></template>


