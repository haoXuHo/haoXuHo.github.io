export const data = JSON.parse("{\"key\":\"v-29070a71\",\"path\":\"/posts/STL%E5%AE%B9%E5%99%A8/%E7%AE%80%E4%BB%8B.html\",\"title\":\"STL简介\",\"lang\":\"zh-CN\",\"frontmatter\":{\"icon\":\"edit\",\"date\":\"2023-04-19T00:00:00.000Z\",\"description\":\"STL简介 STL = Standard Template Library，标准模板库，惠普实验室开发的一系列软件的统称。从根本上说，STL是一些“容器”的集合，这些“容器”有list,vector,set,map等，STL也是算法和其他一些组件的集合。这里的“容器”和算法的集合指的是世界上很多聪明人很多年的杰作。STL的目的是标准化组件，这样就不用重新开发，可以使用现成的组件。STL现在是C++的一部分，因此不用额外安装什么。 容器部分主要由头文件 vector,list,deque,set,map,stack 和queue组成。对于常用的一些容器和容器适配器（可以看作由其它容器实现的容器），可以通过下表总结一下它们和相应头文件的对应关 系。\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/posts/STL%E5%AE%B9%E5%99%A8/%E7%AE%80%E4%BB%8B.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小组博客演示\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"STL简介\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"STL简介 STL = Standard Template Library，标准模板库，惠普实验室开发的一系列软件的统称。从根本上说，STL是一些“容器”的集合，这些“容器”有list,vector,set,map等，STL也是算法和其他一些组件的集合。这里的“容器”和算法的集合指的是世界上很多聪明人很多年的杰作。STL的目的是标准化组件，这样就不用重新开发，可以使用现成的组件。STL现在是C++的一部分，因此不用额外安装什么。 容器部分主要由头文件 vector,list,deque,set,map,stack 和queue组成。对于常用的一些容器和容器适配器（可以看作由其它容器实现的容器），可以通过下表总结一下它们和相应头文件的对应关 系。\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"meta\",{\"property\":\"article:author\",\"content\":\"teamwork\"}],[\"meta\",{\"property\":\"article:published_time\",\"content\":\"2023-04-19T00:00:00.000Z\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"STL简介\\\",\\\"image\\\":[\\\"\\\"],\\\"datePublished\\\":\\\"2023-04-19T00:00:00.000Z\\\",\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"teamwork\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"容器部分主要由头文件\",\"slug\":\"容器部分主要由头文件\",\"link\":\"#容器部分主要由头文件\",\"children\":[]}],\"readingTime\":{\"minutes\":0.73,\"words\":220},\"filePathRelative\":\"posts/STL容器/简介.md\",\"localizedDate\":\"2023年4月19日\",\"excerpt\":\"<h1> STL简介</h1>\\n<p>STL = Standard Template Library，标准模板库，惠普实验室开发的一系列软件的统称。从根本上说，STL是一些“容器”的集合，这些“容器”有list,vector,set,map等，STL也是算法和其他一些组件的集合。这里的“容器”和算法的集合指的是世界上很多聪明人很多年的杰作。STL的目的是标准化组件，这样就不用重新开发，可以使用现成的组件。STL现在是C++的一部分，因此不用额外安装什么。</p>\\n<h2> 容器部分主要由头文件</h2>\\n<p>vector,list,deque,set,map,stack 和queue组成。对于常用的一些容器和容器适配器（可以看作由其它容器实现的容器），可以通过下表总结一下它们和相应头文件的对应关 系。</p>\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
