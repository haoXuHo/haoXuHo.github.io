<template><div><h1 id="队列-queue" tabindex="-1"><a class="header-anchor" href="#队列-queue" aria-hidden="true">#</a> 队列 (Queue)</h1>
<h2 id="外特性-先进先出-fifo" tabindex="-1"><a class="header-anchor" href="#外特性-先进先出-fifo" aria-hidden="true">#</a> 外特性：先进先出(FIFO)</h2>
<ul>
<li>数组实现：元素queue[maxn]，队首head，队尾tail<br>
 入队：queue[tail++] = element;<br>
 出队：element = queue[head++];<br>
 队空条件：head &gt;= tail</li>
</ul>
<h2 id="stl-standard-template-library" tabindex="-1"><a class="header-anchor" href="#stl-standard-template-library" aria-hidden="true">#</a> STL (Standard Template Library)</h2>
<div class="language-c line-numbers-mode" data-ext="c"><pre v-pre class="language-c"><code><span class="token macro property"><span class="token directive-hash">#</span><span class="token directive keyword">include</span> <span class="token expression"><span class="token operator">&amp;</span>lt<span class="token punctuation">;</span>queue<span class="token operator">&amp;</span>gt<span class="token punctuation">;</span>  </span></span>
using namespace std<span class="token punctuation">;</span>  
queue<span class="token operator">&amp;</span>it<span class="token punctuation">;</span><span class="token keyword">int</span><span class="token operator">&amp;</span>gt<span class="token punctuation">;</span> q<span class="token punctuation">;</span>  
<span class="token keyword">int</span> x <span class="token operator">=</span> q<span class="token punctuation">.</span><span class="token function">front</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>  
q<span class="token punctuation">.</span><span class="token function">push</span><span class="token punctuation">(</span>x<span class="token punctuation">)</span><span class="token punctuation">;</span> q<span class="token punctuation">.</span><span class="token function">pop</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span> q<span class="token punctuation">.</span><span class="token function">empty</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span> q<span class="token punctuation">.</span><span class="token function">size</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>  
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="队列的应用" tabindex="-1"><a class="header-anchor" href="#队列的应用" aria-hidden="true">#</a> 队列的应用</h2>
<p>广度优先搜索 （Breadth-first Search）<br>
……</p>
<h2 id="扩展" tabindex="-1"><a class="header-anchor" href="#扩展" aria-hidden="true">#</a> 扩展</h2>
<p>循环队列 （Circular Queue）<br>
最短路的SPFA算法 (Shortest Path Faster Algorithm)  	
双端队列 （Double Ended Queue）<br>
例：Sliding Window<br>
对某些动态规划（Dynamic Programming）<br>
算法进行优化</p>
</div></template>


