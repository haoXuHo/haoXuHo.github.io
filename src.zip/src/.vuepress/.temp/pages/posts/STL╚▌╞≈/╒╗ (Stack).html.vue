<template><div><h1 id="栈-stack" tabindex="-1"><a class="header-anchor" href="#栈-stack" aria-hidden="true">#</a> 栈 (Stack)</h1>
<h2 id="外特性-后进先出-lifo" tabindex="-1"><a class="header-anchor" href="#外特性-后进先出-lifo" aria-hidden="true">#</a> 外特性：后进先出(LIFO)</h2>
<ul>
<li>逻辑结构：只在一端操作的线性表</li>
<li>数组实现：元素 stack[maxn];<br>
   栈顶指针 top;<br>
   入栈(push)：stack[top++] = element;<br>
   出栈(pop)：element = stack[--top];<br>
   空栈条件：top == 0</li>
</ul>
<h2 id="stl-standard-template-library" tabindex="-1"><a class="header-anchor" href="#stl-standard-template-library" aria-hidden="true">#</a> STL (Standard Template Library)</h2>
<div class="language-c line-numbers-mode" data-ext="c"><pre v-pre class="language-c"><code><span class="token macro property"><span class="token directive-hash">#</span><span class="token directive keyword">include</span> <span class="token expression"><span class="token operator">&amp;</span>lt<span class="token punctuation">;</span>stack<span class="token operator">&amp;</span>gt<span class="token punctuation">;</span>  </span></span>
using namespace std<span class="token punctuation">;</span>  
stack <span class="token operator">&amp;</span>lt<span class="token punctuation">;</span><span class="token keyword">int</span><span class="token operator">&amp;</span>gt<span class="token punctuation">;</span> s<span class="token punctuation">;</span>  
<span class="token keyword">int</span> x <span class="token operator">=</span> s<span class="token punctuation">.</span><span class="token function">top</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>  
<span class="token operator">&amp;</span>emsp<span class="token punctuation">;</span>s<span class="token punctuation">.</span><span class="token function">push</span><span class="token punctuation">(</span>x<span class="token punctuation">)</span><span class="token punctuation">;</span>  
<span class="token operator">&amp;</span>emsp<span class="token punctuation">;</span>s<span class="token punctuation">.</span><span class="token function">pop</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>  
<span class="token operator">&amp;</span>emsp<span class="token punctuation">;</span>s<span class="token punctuation">.</span><span class="token function">empty</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span>   
<span class="token operator">&amp;</span>emsp<span class="token punctuation">;</span>s<span class="token punctuation">.</span><span class="token function">size</span><span class="token punctuation">(</span><span class="token punctuation">)</span><span class="token punctuation">;</span> 
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="栈的应用" tabindex="-1"><a class="header-anchor" href="#栈的应用" aria-hidden="true">#</a> 栈的应用</h2>
<p>保护现场 (系统栈)<br>
括号匹配<br>
表达式求值 （The shunting yard algorithm）<br>
深度优先搜索 （Depth-first Search）</p>
</div></template>


