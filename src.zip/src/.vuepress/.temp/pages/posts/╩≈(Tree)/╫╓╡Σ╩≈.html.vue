<template><div><h1 id="字典树-trie" tabindex="-1"><a class="header-anchor" href="#字典树-trie" aria-hidden="true">#</a> 字典树 Trie</h1>
<ul>
<li>设计一个数据结构，能够储存大量字符串</li>
<li>判断某个特定字符串是否存在（不是子串）</li>
<li>类似于在字典中查询某个特定单词是否出现</li>
</ul>
<h2 id="模拟过程" tabindex="-1"><a class="header-anchor" href="#模拟过程" aria-hidden="true">#</a> 模拟过程</h2>
<h3 id="插入一个字符串" tabindex="-1"><a class="header-anchor" href="#插入一个字符串" aria-hidden="true">#</a> 插入一个字符串</h3>
<p>从根节点出发，判断字母所对应的边是否存在<br>
存在  访问对应子节点<br>
不存在 新建子节点<br>
对于终点做特殊标记</p>
<h3 id="查询一个字符串" tabindex="-1"><a class="header-anchor" href="#查询一个字符串" aria-hidden="true">#</a> 查询一个字符串</h3>
<p>直接寻找是否存在对应路径，并且查看路径的终点是否有特殊标记</p>
<h2 id="结构" tabindex="-1"><a class="header-anchor" href="#结构" aria-hidden="true">#</a> 结构</h2>
<ul>
<li>每条边代表一个特定的字符</li>
<li>从根节点到每个节点的路径就是某个字符串的前缀</li>
</ul>
<div class="language-c line-numbers-mode" data-ext="c"><pre v-pre class="language-c"><code><span class="token keyword">struct</span> <span class="token class-name">Trie</span>  
<span class="token punctuation">{</span>  
	<span class="token keyword">int</span> ch<span class="token punctuation">[</span><span class="token number">26</span><span class="token punctuation">]</span><span class="token punctuation">;</span>    
	<span class="token comment">// 记录每个字母是否有对应的子节点（-1或0为不存在）  </span>
	bool flag<span class="token punctuation">;</span>  
<span class="token punctuation">}</span>；  
Trie tr<span class="token punctuation">[</span>MAXN<span class="token punctuation">]</span><span class="token punctuation">;</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="生成字典树" tabindex="-1"><a class="header-anchor" href="#生成字典树" aria-hidden="true">#</a> 生成字典树：</h2>
<h3 id="构建" tabindex="-1"><a class="header-anchor" href="#构建" aria-hidden="true">#</a> 构建</h3>
<div class="language-c line-numbers-mode" data-ext="c"><pre v-pre class="language-c"><code><span class="token keyword">void</span> <span class="token function">createTrie</span><span class="token punctuation">(</span><span class="token keyword">char</span> <span class="token operator">*</span>str<span class="token punctuation">)</span>    
<span class="token punctuation">{</span>    <span class="token keyword">int</span> len <span class="token operator">=</span> <span class="token function">strlen</span><span class="token punctuation">(</span>str<span class="token punctuation">)</span><span class="token punctuation">;</span>  
    Trie <span class="token operator">*</span>p <span class="token operator">=</span> root<span class="token punctuation">,</span> <span class="token operator">*</span>q<span class="token punctuation">;</span>  
    <span class="token keyword">for</span><span class="token punctuation">(</span><span class="token keyword">int</span> i<span class="token operator">=</span><span class="token number">0</span><span class="token punctuation">;</span> i<span class="token operator">&lt;</span>len<span class="token punctuation">;</span> <span class="token operator">++</span>i<span class="token punctuation">)</span>  
    <span class="token punctuation">{</span>  
            <span class="token keyword">int</span> id <span class="token operator">=</span> str<span class="token punctuation">[</span>i<span class="token punctuation">]</span><span class="token operator">-</span><span class="token char">'0'</span><span class="token punctuation">;</span>  
        <span class="token keyword">if</span><span class="token punctuation">(</span>p<span class="token operator">-></span>next<span class="token punctuation">[</span>id<span class="token punctuation">]</span> <span class="token operator">==</span> <span class="token constant">NULL</span><span class="token punctuation">)</span>  
        <span class="token punctuation">{</span>  
                q <span class="token operator">=</span> <span class="token punctuation">(</span>Trie <span class="token operator">*</span><span class="token punctuation">)</span><span class="token function">malloc</span><span class="token punctuation">(</span><span class="token keyword">sizeof</span><span class="token punctuation">(</span>Trie<span class="token punctuation">)</span><span class="token punctuation">)</span><span class="token punctuation">;</span>  
               q<span class="token operator">-></span>v <span class="token operator">=</span> <span class="token number">1</span><span class="token punctuation">;</span>    <span class="token comment">//初始v==1  </span>
                <span class="token keyword">for</span><span class="token punctuation">(</span><span class="token keyword">int</span> j<span class="token operator">=</span><span class="token number">0</span><span class="token punctuation">;</span> j<span class="token operator">&lt;</span>MAX<span class="token punctuation">;</span> <span class="token operator">++</span>j<span class="token punctuation">)</span>  
                   q<span class="token operator">-></span>next<span class="token punctuation">[</span>j<span class="token punctuation">]</span> <span class="token operator">=</span> <span class="token constant">NULL</span><span class="token punctuation">;</span>  
                p<span class="token operator">-></span>next<span class="token punctuation">[</span>id<span class="token punctuation">]</span> <span class="token operator">=</span> q<span class="token punctuation">;</span>  
                p <span class="token operator">=</span> p<span class="token operator">-></span>next<span class="token punctuation">[</span>id<span class="token punctuation">]</span><span class="token punctuation">;</span>  
            <span class="token punctuation">}</span>  
            <span class="token keyword">else</span>  
            <span class="token punctuation">{</span>  
                    p<span class="token operator">-></span>next<span class="token punctuation">[</span>id<span class="token punctuation">]</span><span class="token operator">-></span>v<span class="token operator">++</span><span class="token punctuation">;</span>  
                    p <span class="token operator">=</span> p<span class="token operator">-></span>next<span class="token punctuation">[</span>id<span class="token punctuation">]</span><span class="token punctuation">;</span>  
                <span class="token punctuation">}</span>  
            <span class="token punctuation">}</span>  
            p<span class="token operator">-></span>v <span class="token operator">=</span> <span class="token operator">-</span><span class="token number">1</span><span class="token punctuation">;</span>   <span class="token comment">//若为结尾，则将v改成-1表示  </span>
<span class="token punctuation">}</span>  
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h3 id="查询" tabindex="-1"><a class="header-anchor" href="#查询" aria-hidden="true">#</a> 查询</h3>
<div class="language-c line-numbers-mode" data-ext="c"><pre v-pre class="language-c"><code><span class="token keyword">int</span> <span class="token function">findTrie</span><span class="token punctuation">(</span><span class="token keyword">char</span> <span class="token operator">*</span>str<span class="token punctuation">)</span>  
<span class="token punctuation">{</span>  
        <span class="token keyword">int</span> len <span class="token operator">=</span> <span class="token function">strlen</span><span class="token punctuation">(</span>str<span class="token punctuation">)</span><span class="token punctuation">;</span>  
        Trie <span class="token operator">*</span>p <span class="token operator">=</span> root<span class="token punctuation">;</span>  
        <span class="token keyword">for</span><span class="token punctuation">(</span><span class="token keyword">int</span> i<span class="token operator">=</span><span class="token number">0</span><span class="token punctuation">;</span> i<span class="token operator">&lt;</span>len<span class="token punctuation">;</span> <span class="token operator">++</span>i<span class="token punctuation">)</span>  
        <span class="token punctuation">{</span>  
               <span class="token keyword">int</span> id <span class="token operator">=</span> str<span class="token punctuation">[</span>i<span class="token punctuation">]</span><span class="token operator">-</span><span class="token char">'0'</span><span class="token punctuation">;</span>  
                p <span class="token operator">=</span> p<span class="token operator">-></span>next<span class="token punctuation">[</span>id<span class="token punctuation">]</span><span class="token punctuation">;</span>  
                <span class="token keyword">if</span><span class="token punctuation">(</span>p <span class="token operator">==</span> <span class="token constant">NULL</span><span class="token punctuation">)</span>   <span class="token comment">//若为空集，表示不存以此为前缀的串  </span>
                    <span class="token keyword">return</span> <span class="token number">0</span><span class="token punctuation">;</span>  
                <span class="token keyword">if</span><span class="token punctuation">(</span>p<span class="token operator">-></span>v <span class="token operator">==</span> <span class="token operator">-</span><span class="token number">1</span><span class="token punctuation">)</span>   <span class="token comment">//字符集中已有串是此串的前缀  </span>
                    <span class="token keyword">return</span> <span class="token operator">-</span><span class="token number">1</span><span class="token punctuation">;</span>  
            <span class="token punctuation">}</span>  
            <span class="token keyword">return</span> <span class="token operator">-</span><span class="token number">1</span><span class="token punctuation">;</span>   <span class="token comment">//此串是字符集中某串的前缀  </span>
        <span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div></div></template>


