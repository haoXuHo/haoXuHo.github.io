<template><div><h1 id="并查集-disjoint-set" tabindex="-1"><a class="header-anchor" href="#并查集-disjoint-set" aria-hidden="true">#</a> 并查集 (Disjoint-set)</h1>
<p>合并(Union)两个集合
查找(Find)某元素属于哪个集合</p>
<ul>
<li>每个集合用一棵“有根树”表示<br>
定义数组 set[1…n]<br>
set[i] = i， 则i表示本集合，且是集合对应树的根<br>
set[i] = j，j&lt;&gt;i， 则 j 是 i 的父节点.</li>
</ul>
<h2 id="查找" tabindex="-1"><a class="header-anchor" href="#查找" aria-hidden="true">#</a> 查找</h2>
<div class="language-c line-numbers-mode" data-ext="c"><pre v-pre class="language-c"><code><span class="token keyword">int</span> <span class="token function">findSet</span><span class="token punctuation">(</span><span class="token keyword">int</span> x<span class="token punctuation">)</span>  
<span class="token punctuation">{</span>  
<span class="token operator">&amp;</span>emsp<span class="token punctuation">;</span> <span class="token keyword">if</span> <span class="token punctuation">(</span>x <span class="token operator">==</span> set<span class="token punctuation">[</span>x<span class="token punctuation">]</span><span class="token punctuation">)</span>  
<span class="token operator">&amp;</span>emsp<span class="token punctuation">;</span> <span class="token operator">&amp;</span>emsp<span class="token punctuation">;</span><span class="token keyword">return</span> x<span class="token punctuation">;</span>  
<span class="token operator">&amp;</span>emsp<span class="token punctuation">;</span> <span class="token keyword">else</span>  
<span class="token operator">&amp;</span>emsp<span class="token punctuation">;</span> <span class="token operator">&amp;</span>emsp<span class="token punctuation">;</span><span class="token keyword">return</span> <span class="token function">findSet</span><span class="token punctuation">(</span>set<span class="token punctuation">[</span>x<span class="token punctuation">]</span><span class="token punctuation">)</span><span class="token punctuation">;</span>  
<span class="token punctuation">}</span>
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="合并" tabindex="-1"><a class="header-anchor" href="#合并" aria-hidden="true">#</a> 合并</h2>
<div class="language-c line-numbers-mode" data-ext="c"><pre v-pre class="language-c"><code><span class="token keyword">void</span> <span class="token function">unionSet</span><span class="token punctuation">(</span><span class="token keyword">int</span> x<span class="token punctuation">,</span> <span class="token keyword">int</span> y<span class="token punctuation">)</span>  
<span class="token punctuation">{</span>  
<span class="token operator">&amp;</span>emsp<span class="token punctuation">;</span><span class="token keyword">int</span> fx <span class="token operator">=</span> <span class="token function">findSet</span><span class="token punctuation">(</span>x<span class="token punctuation">)</span><span class="token punctuation">;</span>  
<span class="token operator">&amp;</span>emsp<span class="token punctuation">;</span><span class="token keyword">int</span> fy <span class="token operator">=</span> <span class="token function">findSet</span><span class="token punctuation">(</span>y<span class="token punctuation">)</span><span class="token punctuation">;</span>  
<span class="token operator">&amp;</span>emsp<span class="token punctuation">;</span>set<span class="token punctuation">[</span>fy<span class="token punctuation">]</span> <span class="token operator">=</span> fx<span class="token punctuation">;</span>  
<span class="token punctuation">}</span>  
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><h2 id="优化" tabindex="-1"><a class="header-anchor" href="#优化" aria-hidden="true">#</a> 优化</h2>
<h3 id="启发式合并" tabindex="-1"><a class="header-anchor" href="#启发式合并" aria-hidden="true">#</a> 启发式合并</h3>
<ul>
<li>方法：将深度小的树合并到深度大的树</li>
<li>实现：假设两棵树的深度分别为h1和h2, 则合并后的树的高度h是:
 max(h1,h2), if h1&lt;&gt;h2.<br>
   h1+1, if h1=h2.</li>
<li>效果：任意顺序的合并操作以后，包含k个节点的树的最大高度不超过</li>
</ul>
<h3 id="路径压缩-path-compression" tabindex="-1"><a class="header-anchor" href="#路径压缩-path-compression" aria-hidden="true">#</a> 路径压缩（Path Compression）</h3>
<ul>
<li>
<p>思想：每次查找的时候，把经过路径上的点的父亲都设为根</p>
</li>
<li>
<p>步骤:<br>
 第一步，找到根结点</p>
</li>
</ul>
<p> 第二步，修改查找路径上的所有节点，将它们都指向根结点</p>
<p> 可以证明m次操作的总时间复杂度为k*O(m)，k是一个接近1的常数，即几乎是线性的。</p>
<p> 使用路径压缩的并查集算法不需要再使用启发式合并。</p>
</div></template>


