export const data = JSON.parse("{\"key\":\"v-cbf5ebee\",\"path\":\"/posts/rzb5.html\",\"title\":\"超参数相关内容\",\"lang\":\"zh-CN\",\"frontmatter\":{\"icon\":\"edit\",\"date\":\"2024-04-11T00:00:00.000Z\",\"category\":[\"参数\"],\"tag\":[\"规模大\"],\"description\":\"超参数相关内容 超参数 在机器学习的上下文中，超参数是在开始学习过程之前设置值的参数，而不是通过训练得到的参数数据。通常情况下，需要对超参数进行优化，给学习机选择一组最优超参数，以提高学习的性能和效果超参数具体来讲比如算法中的学习率（learning rate）、梯度下降法迭代的数量（iterations）、隐藏层数目（hidden layers）、隐藏层单元数目、激活函数（ activation function）都需要根据实际情况来设置，这些数字实际上控制了最后的参数和的值，所以它们被称作超参数。 如何寻找超参数的最优值\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/posts/rzb5.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小组博客演示\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"超参数相关内容\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"超参数相关内容 超参数 在机器学习的上下文中，超参数是在开始学习过程之前设置值的参数，而不是通过训练得到的参数数据。通常情况下，需要对超参数进行优化，给学习机选择一组最优超参数，以提高学习的性能和效果超参数具体来讲比如算法中的学习率（learning rate）、梯度下降法迭代的数量（iterations）、隐藏层数目（hidden layers）、隐藏层单元数目、激活函数（ activation function）都需要根据实际情况来设置，这些数字实际上控制了最后的参数和的值，所以它们被称作超参数。 如何寻找超参数的最优值\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"meta\",{\"property\":\"article:author\",\"content\":\"teamwork\"}],[\"meta\",{\"property\":\"article:tag\",\"content\":\"规模大\"}],[\"meta\",{\"property\":\"article:published_time\",\"content\":\"2024-04-11T00:00:00.000Z\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"超参数相关内容\\\",\\\"image\\\":[\\\"\\\"],\\\"datePublished\\\":\\\"2024-04-11T00:00:00.000Z\\\",\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"teamwork\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"超参数\",\"slug\":\"超参数\",\"link\":\"#超参数\",\"children\":[{\"level\":3,\"title\":\"如何寻找超参数的最优值\",\"slug\":\"如何寻找超参数的最优值\",\"link\":\"#如何寻找超参数的最优值\",\"children\":[]}]}],\"readingTime\":{\"minutes\":0.88,\"words\":263},\"filePathRelative\":\"posts/rzb5.md\",\"localizedDate\":\"2024年4月11日\",\"excerpt\":\"<h1> 超参数相关内容</h1>\\n<h2> 超参数</h2>\\n<p>在机器学习的上下文中，超参数是在开始学习过程之前设置值的参数，而不是通过训练得到的参数数据。通常情况下，需要对超参数进行优化，给学习机选择一组最优超参数，以提高学习的性能和效果超参数具体来讲比如算法中的学习率（learning rate）、梯度下降法迭代的数量（iterations）、隐藏层数目（hidden layers）、隐藏层单元数目、激活函数（ activation function）都需要根据实际情况来设置，这些数字实际上控制了最后的参数和的值，所以它们被称作超参数。</p>\\n<h3> 如何寻找超参数的最优值</h3>\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
