export const data = JSON.parse("{\"key\":\"v-32bf179e\",\"path\":\"/posts/%E5%BA%94%E7%94%A8/3.html\",\"title\":\"深度学习图像处理应用\",\"lang\":\"zh-CN\",\"frontmatter\":{\"icon\":\"edit\",\"date\":\"2023-04-13T00:00:00.000Z\",\"category\":[\"应用\"],\"tag\":[\"自动\",\"规模大\"],\"description\":\"深度学习图像处理应用 深度学习图像处理应用 图像处理领域主要应用 图像分类(物体识别)：整幅图像的分类或识别 物体检测：检测图像中物体的位置进而识别物体 图像分割：对图像中的特定物体按边缘进行分割 图像回归：预测图像中物体组成部分的坐标 语音识别领域主要应用 语音识别：将语音识别为文字 声纹识别：识别是哪个人的声音 语音合成：根据文字合成特定人的语音\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/posts/%E5%BA%94%E7%94%A8/3.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小组博客演示\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"深度学习图像处理应用\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"深度学习图像处理应用 深度学习图像处理应用 图像处理领域主要应用 图像分类(物体识别)：整幅图像的分类或识别 物体检测：检测图像中物体的位置进而识别物体 图像分割：对图像中的特定物体按边缘进行分割 图像回归：预测图像中物体组成部分的坐标 语音识别领域主要应用 语音识别：将语音识别为文字 声纹识别：识别是哪个人的声音 语音合成：根据文字合成特定人的语音\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"meta\",{\"property\":\"article:author\",\"content\":\"teamwork\"}],[\"meta\",{\"property\":\"article:tag\",\"content\":\"自动\"}],[\"meta\",{\"property\":\"article:tag\",\"content\":\"规模大\"}],[\"meta\",{\"property\":\"article:published_time\",\"content\":\"2023-04-13T00:00:00.000Z\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"深度学习图像处理应用\\\",\\\"image\\\":[\\\"\\\"],\\\"datePublished\\\":\\\"2023-04-13T00:00:00.000Z\\\",\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"teamwork\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"深度学习图像处理应用\",\"slug\":\"深度学习图像处理应用-1\",\"link\":\"#深度学习图像处理应用-1\",\"children\":[{\"level\":3,\"title\":\"语音识别领域主要应用\",\"slug\":\"语音识别领域主要应用\",\"link\":\"#语音识别领域主要应用\",\"children\":[]}]}],\"readingTime\":{\"minutes\":0.57,\"words\":172},\"filePathRelative\":\"posts/应用/3.md\",\"localizedDate\":\"2023年4月13日\",\"excerpt\":\"<h1> 深度学习图像处理应用</h1>\\n<h2> 深度学习图像处理应用</h2>\\n<p>图像处理领域主要应用</p>\\n<p>图像分类(物体识别)：整幅图像的分类或识别\\n物体检测：检测图像中物体的位置进而识别物体\\n图像分割：对图像中的特定物体按边缘进行分割\\n图像回归：预测图像中物体组成部分的坐标</p>\\n<h3> 语音识别领域主要应用</h3>\\n<p>语音识别：将语音识别为文字\\n声纹识别：识别是哪个人的声音\\n语音合成：根据文字合成特定人的语音</p>\\n\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
