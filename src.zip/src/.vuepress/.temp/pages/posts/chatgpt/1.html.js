export const data = JSON.parse("{\"key\":\"v-711488b9\",\"path\":\"/posts/chatgpt/1.html\",\"title\":\"ChatGPT\",\"lang\":\"zh-CN\",\"frontmatter\":{\"icon\":null,\"date\":\"2023-04-17T00:00:00.000Z\",\"category\":[\"ChatGPT\",\"人工智能\"],\"description\":\"ChatGPT 新型人机交互系统 1.强大的信息处理能力. 2.语言能力强：可以理解和处理多种语言. 3.自我学习能力：基于深度学习构建，可以通过不断学习和训练来提高语言理解和处理能力. 4.可拓展能力强：可根据不同的应用场景进行定制化开发. 链接 ChatGPT.\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/posts/chatgpt/1.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小组博客演示\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"ChatGPT\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"ChatGPT 新型人机交互系统 1.强大的信息处理能力. 2.语言能力强：可以理解和处理多种语言. 3.自我学习能力：基于深度学习构建，可以通过不断学习和训练来提高语言理解和处理能力. 4.可拓展能力强：可根据不同的应用场景进行定制化开发. 链接 ChatGPT.\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"meta\",{\"property\":\"article:author\",\"content\":\"teamwork\"}],[\"meta\",{\"property\":\"article:published_time\",\"content\":\"2023-04-17T00:00:00.000Z\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"ChatGPT\\\",\\\"image\\\":[\\\"\\\"],\\\"datePublished\\\":\\\"2023-04-17T00:00:00.000Z\\\",\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"teamwork\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"新型人机交互系统\",\"slug\":\"新型人机交互系统\",\"link\":\"#新型人机交互系统\",\"children\":[{\"level\":3,\"title\":\"链接\",\"slug\":\"链接\",\"link\":\"#链接\",\"children\":[]}]}],\"readingTime\":{\"minutes\":0.4,\"words\":120},\"filePathRelative\":\"posts/chatgpt/1.md\",\"localizedDate\":\"2023年4月17日\",\"excerpt\":\"<h1> ChatGPT</h1>\\n<h2> 新型人机交互系统</h2>\\n<p>1.强大的信息处理能力.</p>\\n<p>2.语言能力强：可以理解和处理多种语言.</p>\\n<p>3.自我学习能力：基于深度学习构建，可以通过不断学习和训练来提高语言理解和处理能力.</p>\\n<p>4.可拓展能力强：可根据不同的应用场景进行定制化开发.</p>\\n<h3> 链接</h3>\\n<p><img src=\\\"/chatgpt.png\\\" alt=\\\"\\\" loading=\\\"lazy\\\">\\n<a href=\\\"https://chat.openai.com/\\\" target=\\\"_blank\\\" rel=\\\"noopener noreferrer\\\">ChatGPT</a>.</p>\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
