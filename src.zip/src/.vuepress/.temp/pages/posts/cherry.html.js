export const data = JSON.parse("{\"key\":\"v-2bc6566a\",\"path\":\"/posts/cherry.html\",\"title\":\"稻城亚丁\",\"lang\":\"zh-CN\",\"frontmatter\":{\"icon\":\"edit\",\"date\":\"2023-04-17T00:00:00.000Z\",\"category\":[\"景点推荐\"],\"description\":\"稻城亚丁 我希望有个如你一般的人，如山间清爽的风，如古城温暖的光，从清晨到夜晚，由山野到书房，等待......不怕岁月蹉跎，不怕路途遥远，只要最后是你就好。 浮世三千，吾爱有三。日、月与卿。日为朝，月为暮，卿为朝朝暮暮。稻城亚丁的蓝天、白云、神山、圣水，没有一处不令人着迷，行至此处，甚至产生了一种想要永远留下的冲动。\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/posts/cherry.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小组博客演示\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"稻城亚丁\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"稻城亚丁 我希望有个如你一般的人，如山间清爽的风，如古城温暖的光，从清晨到夜晚，由山野到书房，等待......不怕岁月蹉跎，不怕路途遥远，只要最后是你就好。 浮世三千，吾爱有三。日、月与卿。日为朝，月为暮，卿为朝朝暮暮。稻城亚丁的蓝天、白云、神山、圣水，没有一处不令人着迷，行至此处，甚至产生了一种想要永远留下的冲动。\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"meta\",{\"property\":\"article:author\",\"content\":\"teamwork\"}],[\"meta\",{\"property\":\"article:published_time\",\"content\":\"2023-04-17T00:00:00.000Z\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"稻城亚丁\\\",\\\"image\\\":[\\\"\\\"],\\\"datePublished\\\":\\\"2023-04-17T00:00:00.000Z\\\",\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"teamwork\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"\",\"slug\":\"\",\"link\":\"#\",\"children\":[{\"level\":3,\"title\":\"\",\"slug\":\"-1\",\"link\":\"#-1\",\"children\":[]}]}],\"readingTime\":{\"minutes\":0.77,\"words\":230},\"filePathRelative\":\"posts/cherry.md\",\"localizedDate\":\"2023年4月17日\",\"excerpt\":\"<h1> 稻城亚丁</h1>\\n<h2> </h2>\\n<p><img src=\\\"/dao1.jpg\\\" alt=\\\"\\\" loading=\\\"lazy\\\">\\n<img src=\\\"/dao2.jpg\\\" alt=\\\"\\\" loading=\\\"lazy\\\"></p>\\n<h3> </h3>\\n<p>我希望有个如你一般的人，如山间清爽的风，如古城温暖的光，从清晨到夜晚，由山野到书房，等待......不怕岁月蹉跎，不怕路途遥远，只要最后是你就好。</p>\\n<p>浮世三千，吾爱有三。日、月与卿。日为朝，月为暮，卿为朝朝暮暮。稻城亚丁的蓝天、白云、神山、圣水，没有一处不令人着迷，行至此处，甚至产生了一种想要永远留下的冲动。</p>\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
