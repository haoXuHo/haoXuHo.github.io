<template><div><h1 id="嗨-你好呀" tabindex="-1"><a class="header-anchor" href="#嗨-你好呀" aria-hidden="true">#</a> 嗨，你好呀!</h1>
<h2 id="html学习笔记" tabindex="-1"><a class="header-anchor" href="#html学习笔记" aria-hidden="true">#</a> HTML学习笔记</h2>
<p>半个学期过去了，我在<code v-pre>Web</code>课里学了些什么呢?盘点一下吧.</p>
<h3 id="开始" tabindex="-1"><a class="header-anchor" href="#开始" aria-hidden="true">#</a> 开始</h3>
<p><code v-pre>&lt;html&gt; 内容... &lt;/html&gt;</code></p>
<ul>
<li>让计算机识别这是一个<em>HTML</em>文档.</li>
</ul>
<h3 id="头" tabindex="-1"><a class="header-anchor" href="#头" aria-hidden="true">#</a> 头</h3>
<p><code v-pre>&lt;head&gt; 内容... &lt;/head&gt;</code>  <em>以后这个结束符不特殊注明就省略了 懒~</em></p>
<ul>
<li>emm我能说没发现和下文的body有什么区别吗</li>
<li>就是可以链接css文档? 放<code v-pre>&lt;title&gt;</code>标签? 我其实没有太懂...</li>
</ul>
<h4 id="命名网页" tabindex="-1"><a class="header-anchor" href="#命名网页" aria-hidden="true">#</a> 命名网页</h4>
<p><code v-pre>&lt;title&gt;</code></p>
<ul>
<li>就是上文提到的那个</li>
</ul>
<h3 id="主体部分" tabindex="-1"><a class="header-anchor" href="#主体部分" aria-hidden="true">#</a> 主体部分</h3>
<p><code v-pre>&lt;body&gt;</code></p>
<ul>
<li>html网页的主题部分</li>
</ul>
<h3 id="注释" tabindex="-1"><a class="header-anchor" href="#注释" aria-hidden="true">#</a> 注释</h3>
<p><code v-pre>&lt;!--在这里填写注释的内容--&gt;</code></p>
<h3 id="格式化字体" tabindex="-1"><a class="header-anchor" href="#格式化字体" aria-hidden="true">#</a> 格式化字体</h3>
<div class="hint-container info">
<p class="hint-container-title">格式化大集合!</p>
<pre><code>&lt;b&gt; 加粗字体    
&lt;strong&gt; 加粗字体且朗读此处时重读  
&lt;i&gt; 斜体        
&lt;em&gt; 强调字体  
&lt;big&gt; 放大字体  
&lt;small&gt; 缩小字体  
&lt;sub&gt; 下标      
&lt;sup&gt; 上标
</code></pre>
</div>
<h3 id="标题-段落和换行" tabindex="-1"><a class="header-anchor" href="#标题-段落和换行" aria-hidden="true">#</a> 标题 段落和换行</h3>
<h4 id="段落" tabindex="-1"><a class="header-anchor" href="#段落" aria-hidden="true">#</a> 段落</h4>
<p><code v-pre>&lt;p&gt;</code></p>
<ul>
<li>段落除了可以自动换行,还可以在段落前后添加一个空行</li>
</ul>
<h4 id="标题" tabindex="-1"><a class="header-anchor" href="#标题" aria-hidden="true">#</a> 标题</h4>
<p><code v-pre>&lt;hi&gt; i = 1, 2, ..., 6</code></p>
<ul>
<li>从1到6标题字体逐渐减少,且自动换行</li>
</ul>
<h4 id="换行" tabindex="-1"><a class="header-anchor" href="#换行" aria-hidden="true">#</a> 换行</h4>
<p><code v-pre>&lt;br&gt; 注意这是个空标签,是没有结束符的</code></p>
<h3 id="实体" tabindex="-1"><a class="header-anchor" href="#实体" aria-hidden="true">#</a> 实体</h3>
<ul>
<li>&quot; &quot;空格(不可分割的)可以用<code v-pre>&amp;nbsp</code>来表示</li>
<li>上面的是最常用的,其他的自行查表即可</li>
</ul>
<div class="hint-container warning">
<p class="hint-container-title">注意!</p>
<p>由于HTML格式存在关键字,故不能直接输出字符</p>
</div>
<h3 id="锚-链接和章节" tabindex="-1"><a class="header-anchor" href="#锚-链接和章节" aria-hidden="true">#</a> 锚,链接和章节</h3>
<h4 id="创建链接" tabindex="-1"><a class="header-anchor" href="#创建链接" aria-hidden="true">#</a> 创建链接</h4>
<p><code v-pre>&lt;a&gt;</code></p>
<h5 id="属性" tabindex="-1"><a class="header-anchor" href="#属性" aria-hidden="true">#</a> 属性</h5>
<ul>
<li>href : <code v-pre>&lt;a href=&quot;url&quot;&gt; 超链接文本 &lt;/a&gt;</code></li>
</ul>
<blockquote>
<p>URL就是你要链接的网站地址</p>
</blockquote>
<ul>
<li>target : <code v-pre>&lt;a href=&quot;url&quot; target=&quot;打开方式&quot;&gt; 超链接文本 &lt;/a&gt;</code></li>
</ul>
<blockquote>
<p>打开方式有两种:
1. &quot;_self&quot; 默认窗口弹出方式
2. &quot;_blank&quot; 新窗口弹出</p>
</blockquote>
<ul>
<li>name : <code v-pre>&lt;a name=&quot;锚的名字&quot;&gt; 展示文本 &lt;/a&gt;</code></li>
</ul>
<blockquote>
<p>命名本身无意义,主要是可以将网页直接链接到对应锚的名字的那个章节</p>
</blockquote>
<h3 id="列表" tabindex="-1"><a class="header-anchor" href="#列表" aria-hidden="true">#</a> 列表</h3>
<h4 id="无序列表" tabindex="-1"><a class="header-anchor" href="#无序列表" aria-hidden="true">#</a> 无序列表</h4>
<ul>
<li><code v-pre>&lt;ul&gt;</code> 作为开头</li>
<li><code v-pre>&lt;li&gt;</code> 列表中每一目的具体内容</li>
</ul>
<h4 id="有序列表" tabindex="-1"><a class="header-anchor" href="#有序列表" aria-hidden="true">#</a> 有序列表</h4>
<ul>
<li><code v-pre>&lt;ol&gt;</code> 作为开头</li>
<li><code v-pre>&lt;li&gt;</code> 列表中每一目的具体内容且自动补充序号</li>
</ul>
<h3 id="自定义列表" tabindex="-1"><a class="header-anchor" href="#自定义列表" aria-hidden="true">#</a> 自定义列表</h3>
<blockquote>
<p>它是一系列条目及它们的解释</p>
</blockquote>
<ul>
<li><code v-pre>&lt;dl&gt;</code> 作为开始</li>
<li><code v-pre>&lt;dt&gt;</code> 要解释的条目</li>
<li><code v-pre>&lt;dd&gt;</code> 解释内容,可以为段落,换行,图像等</li>
</ul>
<h3 id="插入图像" tabindex="-1"><a class="header-anchor" href="#插入图像" aria-hidden="true">#</a> 插入图像</h3>
<h4 id="图像" tabindex="-1"><a class="header-anchor" href="#图像" aria-hidden="true">#</a> 图像</h4>
<ul>
<li><code v-pre>&lt;img&gt; 也是空标签</code></li>
</ul>
<h5 id="属性-1" tabindex="-1"><a class="header-anchor" href="#属性-1" aria-hidden="true">#</a> 属性</h5>
<ol>
<li><code v-pre>src</code> (源)
- <code v-pre>&lt;img src=&quot;url&quot;&gt;</code>
- url是这个图像的地址</li>
<li><code v-pre>alt</code> (交互文本)
- <code v-pre>&lt;img src=&quot;boat.gif&quot; alt=&quot;Big Boat&quot;&gt;</code>
- 当图片丢失时,以文本形式告诉用户丢失的信息</li>
</ol>
<h3 id="html表单" tabindex="-1"><a class="header-anchor" href="#html表单" aria-hidden="true">#</a> HTML表单</h3>
<h4 id="创建表单" tabindex="-1"><a class="header-anchor" href="#创建表单" aria-hidden="true">#</a> 创建表单</h4>
<ul>
<li><code v-pre>&lt;form&gt;</code></li>
<li>有了这个格式后才有下面的内容</li>
</ul>
<h4 id="文本输入框" tabindex="-1"><a class="header-anchor" href="#文本输入框" aria-hidden="true">#</a> 文本输入框</h4>
<ul>
<li><code v-pre>&lt;input&gt; 空标签</code></li>
</ul>
<h5 id="文本框" tabindex="-1"><a class="header-anchor" href="#文本框" aria-hidden="true">#</a> 文本框</h5>
<ul>
<li><code v-pre>&lt;input type=&quot;text&quot; name=&quot;...&quot;&gt;</code></li>
<li>创建一个可输入文本的方框</li>
</ul>
<blockquote>
<p>使用<code v-pre>value = &quot;V&quot;</code>可设置初始值为<code v-pre>V</code></p>
</blockquote>
<h5 id="单选按钮" tabindex="-1"><a class="header-anchor" href="#单选按钮" aria-hidden="true">#</a> 单选按钮</h5>
<ul>
<li><code v-pre>&lt;input type=&quot;radio&quot; name=&quot;...&quot;&gt; 选项文本</code></li>
<li>只会创建一个供选择的地方,选项内容还得自己写</li>
</ul>
<blockquote>
<p>若<code v-pre>name</code>不一致则会出现&quot;单选框多选&quot;的现象</p>
</blockquote>
<h5 id="复选按钮" tabindex="-1"><a class="header-anchor" href="#复选按钮" aria-hidden="true">#</a> 复选按钮</h5>
<ul>
<li><code v-pre>&lt;input type=&quot;checkbox&quot; name=&quot;...&quot;&gt; 选项文本</code></li>
<li>只会创建一个可复选的地方</li>
</ul>
<h5 id="提交文件" tabindex="-1"><a class="header-anchor" href="#提交文件" aria-hidden="true">#</a> 提交文件</h5>
<ul>
<li><code v-pre>&lt;form name=&quot;input&quot; action=&quot;submit.asp&quot; method=&quot;...&quot;&gt;</code></li>
<li>将<code v-pre>name</code>表单上传到<code v-pre>action</code>指定的文件内</li>
<li><code v-pre>method</code> 属性
<ul>
<li><code v-pre>get</code> 长度有限,不用于发送敏感数据,能加入标签</li>
<li><code v-pre>post</code> 上面那个的反义词</li>
</ul>
</li>
</ul>
<h5 id="创建按钮" tabindex="-1"><a class="header-anchor" href="#创建按钮" aria-hidden="true">#</a> 创建按钮</h5>
<ul>
<li><code v-pre>&lt;input type=&quot;button&quot; value=&quot;...&quot;&gt;</code></li>
<li><code v-pre>value</code> 值为按钮文本</li>
</ul>
<h4 id="选项框-带下拉列表" tabindex="-1"><a class="header-anchor" href="#选项框-带下拉列表" aria-hidden="true">#</a> 选项框,带下拉列表</h4>
<ul>
<li><code v-pre>&lt;select name=&quot;...&quot;&gt;</code></li>
<li>在标签内补充下拉列表的选项:
<ul>
<li><code v-pre>&lt;option value=&quot;返回值&quot;&gt; 选项内容</code></li>
<li>有多少个选项就有多少个<code v-pre>option</code></li>
<li><code v-pre>&lt;option value=&quot;V&quot; selected&gt; 选项内容</code></li>
<li>这表示<code v-pre>V</code>是预选项</li>
</ul>
</li>
</ul>
<h4 id="文本域" tabindex="-1"><a class="header-anchor" href="#文本域" aria-hidden="true">#</a> 文本域</h4>
<ul>
<li><code v-pre>&lt;textarea rows=&quot;i&quot; cols=&quot;j&quot;&gt;</code></li>
<li>输入<code v-pre>i</code>行<code v-pre>j</code>列文本</li>
<li>输入文本数不受限制</li>
</ul>
</div></template>


