<template><div><h1 id="稻城亚丁" tabindex="-1"><a class="header-anchor" href="#稻城亚丁" aria-hidden="true">#</a> 稻城亚丁</h1>
<h2 id="" tabindex="-1"><a class="header-anchor" href="#" aria-hidden="true">#</a> </h2>
<p><img src="/dao1.jpg" alt="" loading="lazy">
<img src="/dao2.jpg" alt="" loading="lazy"></p>
<h3 id="-1" tabindex="-1"><a class="header-anchor" href="#-1" aria-hidden="true">#</a> </h3>
<p>我希望有个如你一般的人，如山间清爽的风，如古城温暖的光，从清晨到夜晚，由山野到书房，等待......不怕岁月蹉跎，不怕路途遥远，只要最后是你就好。</p>
<p>浮世三千，吾爱有三。日、月与卿。日为朝，月为暮，卿为朝朝暮暮。稻城亚丁的蓝天、白云、神山、圣水，没有一处不令人着迷，行至此处，甚至产生了一种想要永远留下的冲动。</p>
<p>人活到一定的年纪总会带着一点难言的痛，煎熬着、承受着、挣扎着，突然有一天，没有任何征兆的、没有任何目的、没有任何理由和借口的背起行囊选择出发。只要你有勇气重新出发，就能遇见一个全新的自己！</p>
<h4 id="-2" tabindex="-1"><a class="header-anchor" href="#-2" aria-hidden="true">#</a> </h4>
<p><img src="/dao3.jpeg" alt="" loading="lazy">
<img src="/dao4.jpg" alt="" loading="lazy">
<img src="/dao5.jpg" alt="" loading="lazy"></p>
</div></template>


