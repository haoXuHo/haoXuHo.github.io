<template><div><h1 id="传播方式" tabindex="-1"><a class="header-anchor" href="#传播方式" aria-hidden="true">#</a> 传播方式</h1>
<h2 id="前向传播" tabindex="-1"><a class="header-anchor" href="#前向传播" aria-hidden="true">#</a> 前向传播</h2>
<p>假设上一层结点i , j , k , . . . i,j,k,...i,j,k,...等一些结点与本层的结点w ww有连接，那么结点w ww的值怎么算呢？就是通过上一层的i , j , k , . . . i,j,k,...i,j,k,...等结点以及对应的连接权值进行加权和运算，最终结果再加上一个偏置项（图中为了简单省略了），最后在通过一个非线性函数（即激活函数），如R e L u ReLuReLu，s i g m o i d sigmoidsigmoid等函数，最后得到的结果就是本层结点w ww的输出。</p>
<p>最终不断的通过这种方法一层层的运算，得到输出层结果。</p>
<h3 id="反向传播" tabindex="-1"><a class="header-anchor" href="#反向传播" aria-hidden="true">#</a> 反向传播</h3>
<p>由于我们前向传播最终得到的结果，以分类为例，最终总是有误差的，那么怎么减少误差呢，当前应用广泛的一个算法就是梯度下降算法，但是求梯度就要求偏导数</p>
</div></template>


