<template><div><h1 id="超参数相关内容" tabindex="-1"><a class="header-anchor" href="#超参数相关内容" aria-hidden="true">#</a> 超参数相关内容</h1>
<h2 id="超参数" tabindex="-1"><a class="header-anchor" href="#超参数" aria-hidden="true">#</a> 超参数</h2>
<p>在机器学习的上下文中，超参数是在开始学习过程之前设置值的参数，而不是通过训练得到的参数数据。通常情况下，需要对超参数进行优化，给学习机选择一组最优超参数，以提高学习的性能和效果超参数具体来讲比如算法中的学习率（learning rate）、梯度下降法迭代的数量（iterations）、隐藏层数目（hidden layers）、隐藏层单元数目、激活函数（ activation function）都需要根据实际情况来设置，这些数字实际上控制了最后的参数和的值，所以它们被称作超参数。</p>
<h3 id="如何寻找超参数的最优值" tabindex="-1"><a class="header-anchor" href="#如何寻找超参数的最优值" aria-hidden="true">#</a> 如何寻找超参数的最优值</h3>
<p>在使用机器学习算法时，总有一些难调的超参数。例如权重衰减大小，高斯核宽度等等。这些参数需要人为设置，设置的值对结果产生较大影响。</p>
</div></template>


