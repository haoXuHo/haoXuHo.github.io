<template><div><h1 id="自然语言应用" tabindex="-1"><a class="header-anchor" href="#自然语言应用" aria-hidden="true">#</a> 自然语言应用</h1>
<h2 id="自然语言处理领域主要应用" tabindex="-1"><a class="header-anchor" href="#自然语言处理领域主要应用" aria-hidden="true">#</a> 自然语言处理领域主要应用</h2>
<p>语言模型：根据之前词预测下一个单词。
情感分析：分析文本体现的情感(正负向、正负中或多态度类型)。
神经机器翻译：基于统计语言模型的多语种互译。
神经自动摘要：根据文本自动生成摘要。
机器阅读理解：通过阅读文本回答问题、完成选择题或完型填空。
自然语言推理：根据一句话(前提)推理出另一句话(结论)。</p>
<h3 id="综合应用" tabindex="-1"><a class="header-anchor" href="#综合应用" aria-hidden="true">#</a> 综合应用</h3>
<p>图像描述：根据图像给出图像的描述句子
可视问答：根据图像或视频回答问题
图像生成：根据文本描述生成图像
视频生成：根据故事自动生成视频</p>
</div></template>


