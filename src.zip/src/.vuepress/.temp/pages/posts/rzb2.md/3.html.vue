<template><div><h1 id="深度学习图像处理应用" tabindex="-1"><a class="header-anchor" href="#深度学习图像处理应用" aria-hidden="true">#</a> 深度学习图像处理应用</h1>
<h2 id="深度学习图像处理应用-1" tabindex="-1"><a class="header-anchor" href="#深度学习图像处理应用-1" aria-hidden="true">#</a> 深度学习图像处理应用</h2>
<p>图像处理领域主要应用</p>
<p>图像分类(物体识别)：整幅图像的分类或识别
物体检测：检测图像中物体的位置进而识别物体
图像分割：对图像中的特定物体按边缘进行分割
图像回归：预测图像中物体组成部分的坐标</p>
<h3 id="语音识别领域主要应用" tabindex="-1"><a class="header-anchor" href="#语音识别领域主要应用" aria-hidden="true">#</a> 语音识别领域主要应用</h3>
<p>语音识别：将语音识别为文字
声纹识别：识别是哪个人的声音
语音合成：根据文字合成特定人的语音</p>
</div></template>


