<template><div><h1 id="chatgpt" tabindex="-1"><a class="header-anchor" href="#chatgpt" aria-hidden="true">#</a> ChatGPT</h1>
<h2 id="新型人机交互系统" tabindex="-1"><a class="header-anchor" href="#新型人机交互系统" aria-hidden="true">#</a> 新型人机交互系统</h2>
<p>1.强大的信息处理能力.</p>
<p>2.语言能力强：可以理解和处理多种语言.</p>
<p>3.自我学习能力：基于深度学习构建，可以通过不断学习和训练来提高语言理解和处理能力.</p>
<p>4.可拓展能力强：可根据不同的应用场景进行定制化开发.</p>
<h3 id="链接" tabindex="-1"><a class="header-anchor" href="#链接" aria-hidden="true">#</a> 链接</h3>
<p><img src="/chatgpt.png" alt="" loading="lazy">
<a href="https://chat.openai.com/" target="_blank" rel="noopener noreferrer">ChatGPT<ExternalLinkIcon/></a>.</p>
</div></template>


