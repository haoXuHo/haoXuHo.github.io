export const data = JSON.parse("{\"key\":\"v-7eea36f4\",\"path\":\"/posts/apple/apple/2.html\",\"title\":\"Chat open ai\",\"lang\":\"en-US\",\"frontmatter\":{\"icon\":\"edit\",\"date\":\"2023-04-17T00:00:00.000Z\",\"category\":[\"ChatGPT\"],\"star\":true,\"description\":\"Chat open ai AI人工智能\"},\"headers\":[{\"level\":2,\"title\":\"标题 2\",\"slug\":\"标题-2\",\"link\":\"#标题-2\",\"children\":[{\"level\":3,\"title\":\"标题 3\",\"slug\":\"标题-3\",\"link\":\"#标题-3\",\"children\":[]}]}],\"readingTime\":{\"minutes\":0.12,\"words\":35},\"filePathRelative\":\"posts/apple/apple/2.md\",\"localizedDate\":\"April 17, 2023\",\"excerpt\":\"<h1> Chat open ai</h1>\\n<p>AI人工智能</p>\\n\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
