export const data = JSON.parse("{\"key\":\"v-8253e832\",\"path\":\"/posts/apple/apple/1.html\",\"title\":\"变形金刚\",\"lang\":\"en-US\",\"frontmatter\":{\"icon\":\"edit\",\"date\":\"2023-04-17T00:00:00.000Z\",\"category\":[\"carman\"],\"description\":\"变形金刚 擎天柱 标题 3 这里是内容。\"},\"headers\":[{\"level\":2,\"title\":\"擎天柱\",\"slug\":\"擎天柱\",\"link\":\"#擎天柱\",\"children\":[{\"level\":3,\"title\":\"标题 3\",\"slug\":\"标题-3\",\"link\":\"#标题-3\",\"children\":[]}]}],\"readingTime\":{\"minutes\":0.08,\"words\":23},\"filePathRelative\":\"posts/apple/apple/1.md\",\"localizedDate\":\"April 17, 2023\",\"excerpt\":\"<h1> 变形金刚</h1>\\n<h2> 擎天柱</h2>\\n<h3> 标题 3</h3>\\n<p>这里是内容。</p>\\n\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
