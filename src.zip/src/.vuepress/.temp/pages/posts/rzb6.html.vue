<template><div><h1 id="感知机" tabindex="-1"><a class="header-anchor" href="#感知机" aria-hidden="true">#</a> 感知机</h1>
<figure><img src="/deeplearning,jpg" alt="" tabindex="0" loading="lazy"><figcaption></figcaption></figure>
<h2 id="多层感知机" tabindex="-1"><a class="header-anchor" href="#多层感知机" aria-hidden="true">#</a> 多层感知机</h2>
<p>多层感知机由感知机推广而来，最主要的特点是有多个神经元层，因此也叫深度神经网络。相比于单独的感知机，多层感知机的第i ii层的每个神经元和第i − 1 i-1i−1层的每个神经元都有连接。</p>
<h3 id="前向传播和反向传播介绍" tabindex="-1"><a class="header-anchor" href="#前向传播和反向传播介绍" aria-hidden="true">#</a> 前向传播和反向传播介绍</h3>
<p>神经网络的计算主要有两种：前向传播（foward propagation, FP）作用于每一层的输入，通过逐层计算得到输出结果；反向传播（backward propagation, BP）作用于网络的输出，通过计算梯度由深到浅更新网络参数</p>
</div></template>


