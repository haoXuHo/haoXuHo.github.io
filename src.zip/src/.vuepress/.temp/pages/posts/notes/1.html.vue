<template><div><h1 id="markdown" tabindex="-1"><a class="header-anchor" href="#markdown" aria-hidden="true">#</a> MarkDown</h1>
<p>Markdown是一种轻量级标记语言，它使用易读易写的纯文本格式编写，可转换为HTML、PDF、Word等多种格式的文档。Markdown的语法简洁明了，易于学习和使用，被广泛应用于写作、博客、文档等领域。</p>
<h2 id="" tabindex="-1"><a class="header-anchor" href="#" aria-hidden="true">#</a> </h2>
<p>1.标题：使用 # 符号表示标题，# 的数量表示标题的级别，一级标题用一个 #，二级标题用两个 #，以此类推。例如：</p>
<div class="language-markdowm line-numbers-mode" data-ext="markdowm"><pre v-pre class="language-markdowm"><code># 一级标题
## 二级标题
### 三级标题
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>2.段落和换行：用空行来分隔段落，一行结束后，输入两个及以上的空格再回车可实现换行。</p>
<p>3.列表：使用 *、+、- 符号表示无序列表，使用数字加英文句点表示有序列表。例如：</p>
<div class="language-markdowm line-numbers-mode" data-ext="markdowm"><pre v-pre class="language-markdowm"><code>* 无序列表项1
* 无序列表项2
1. 有序列表项1
2. 有序列表项2
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>4.引用：使用 &gt; 符号表示引用。例如：</p>
<div class="language-markdowm line-numbers-mode" data-ext="markdowm"><pre v-pre class="language-markdowm"><code>&gt; 这是一段引用的文字。
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>5.链接和图片：使用 [] 和 () 符号表示链接和图片。例如：</p>
<div class="language-markdowm line-numbers-mode" data-ext="markdowm"><pre v-pre class="language-markdowm"><code>[百度](https://www.baidu.com)
![图片描述](https://www.example.com/images/pic.jpg)
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div></div></div><p>6.粗体和斜体：使用 ** 和 * 符号表示粗体和斜体。例如：</p>
<div class="language-markdowm line-numbers-mode" data-ext="markdowm"><pre v-pre class="language-markdowm"><code>**这是粗体**
*这是斜体*
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div></div></div><p>7.代码块：使用 ``` 符号表示代码块，可以指定代码块的语言类型。例如：</p>
<div class="language-markdowm line-numbers-mode" data-ext="markdowm"><pre v-pre class="language-markdowm"><code>​``` python
def hello():
    print(&quot;Hello, world!&quot;)
​```
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>8.表格：使用 | 和 - 符号表示表格，其中第一行为表头，第二行为分隔线，第三行及以下为表格内容。例如：</p>
<div class="language-markdowm line-numbers-mode" data-ext="markdowm"><pre v-pre class="language-markdowm"><code>|  名字  | 年龄 |  性别  |
| ------ | --- | ------ |
| 张三   |  20 |  男   |
| 李四   |  18 |  女   |
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div><div class="line-number"></div></div></div><p>9.分割线：使用三个或以上的 - 或 * 符号表示分割线。例如：</p>
<div class="language-markdowm line-numbers-mode" data-ext="markdowm"><pre v-pre class="language-markdowm"><code>---
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>10.删除线：使用 ~~ 符号表示删除线。例如：</p>
<div class="language-markdowm line-numbers-mode" data-ext="markdowm"><pre v-pre class="language-markdowm"><code>~~这段文字将会被删除~~
</code></pre><div class="line-numbers" aria-hidden="true"><div class="line-number"></div></div></div><p>(暂时就这些啦)</p>
<h5 id="created-by-徐浩" tabindex="-1"><a class="header-anchor" href="#created-by-徐浩" aria-hidden="true">#</a> created by 徐浩</h5>
</div></template>


