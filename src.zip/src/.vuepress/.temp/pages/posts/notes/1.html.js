export const data = JSON.parse("{\"key\":\"v-af1eac6a\",\"path\":\"/posts/notes/1.html\",\"title\":\"MarkDown\",\"lang\":\"zh-CN\",\"frontmatter\":{\"icon\":\"edit\",\"date\":\"2023-04-18T00:00:00.000Z\",\"category\":[\"notes\"],\"tag\":[\"学习学习学习！\"],\"description\":\"MarkDown Markdown是一种轻量级标记语言，它使用易读易写的纯文本格式编写，可转换为HTML、PDF、Word等多种格式的文档。Markdown的语法简洁明了，易于学习和使用，被广泛应用于写作、博客、文档等领域。 1.标题：使用 # 符号表示标题，# 的数量表示标题的级别，一级标题用一个 #，二级标题用两个 #，以此类推。例如： # 一级标题 ## 二级标题 ### 三级标题\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/posts/notes/1.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小组博客演示\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"MarkDown\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"MarkDown Markdown是一种轻量级标记语言，它使用易读易写的纯文本格式编写，可转换为HTML、PDF、Word等多种格式的文档。Markdown的语法简洁明了，易于学习和使用，被广泛应用于写作、博客、文档等领域。 1.标题：使用 # 符号表示标题，# 的数量表示标题的级别，一级标题用一个 #，二级标题用两个 #，以此类推。例如： # 一级标题 ## 二级标题 ### 三级标题\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"meta\",{\"property\":\"article:author\",\"content\":\"teamwork\"}],[\"meta\",{\"property\":\"article:tag\",\"content\":\"学习学习学习！\"}],[\"meta\",{\"property\":\"article:published_time\",\"content\":\"2023-04-18T00:00:00.000Z\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"MarkDown\\\",\\\"image\\\":[\\\"\\\"],\\\"datePublished\\\":\\\"2023-04-18T00:00:00.000Z\\\",\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"teamwork\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"\",\"slug\":\"\",\"link\":\"#\",\"children\":[]}],\"readingTime\":{\"minutes\":1.55,\"words\":465},\"filePathRelative\":\"posts/notes/1.md\",\"localizedDate\":\"2023年4月18日\",\"excerpt\":\"<h1> MarkDown</h1>\\n<p>Markdown是一种轻量级标记语言，它使用易读易写的纯文本格式编写，可转换为HTML、PDF、Word等多种格式的文档。Markdown的语法简洁明了，易于学习和使用，被广泛应用于写作、博客、文档等领域。</p>\\n<h2> </h2>\\n<p>1.标题：使用 # 符号表示标题，# 的数量表示标题的级别，一级标题用一个 #，二级标题用两个 #，以此类推。例如：</p>\\n<div class=\\\"language-markdowm line-numbers-mode\\\" data-ext=\\\"markdowm\\\"><pre class=\\\"language-markdowm\\\"><code># 一级标题\\n## 二级标题\\n### 三级标题\\n</code></pre><div class=\\\"line-numbers\\\" aria-hidden=\\\"true\\\"><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div><div class=\\\"line-number\\\"></div></div></div>\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
