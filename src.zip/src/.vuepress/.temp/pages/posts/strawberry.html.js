export const data = JSON.parse("{\"key\":\"v-f0ec4556\",\"path\":\"/posts/strawberry.html\",\"title\":\"看看风景\",\"lang\":\"zh-CN\",\"frontmatter\":{\"icon\":\"edit\",\"date\":\"2023-04-16T00:00:00.000Z\",\"category\":[\"景点推荐\"],\"tag\":[\"风景\"],\"description\":\"看看风景 冰岛 冰岛是一个神秘而美丽的地方 从远处望去，仿佛是一块被时间遗忘的冰川巨石，在北极圈内，漫长的白夜和太阳的轨迹，是它独特的自然景观。 在这里，天空常年飘舞着缤纷绚烂的极光，如同色彩斑斓的帷幕，为这座冰岛添上了一份梦幻的色彩 介绍 总得去一次吧 不确定再看看\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/posts/strawberry.html\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小组博客演示\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"看看风景\"}],[\"meta\",{\"property\":\"og:description\",\"content\":\"看看风景 冰岛 冰岛是一个神秘而美丽的地方 从远处望去，仿佛是一块被时间遗忘的冰川巨石，在北极圈内，漫长的白夜和太阳的轨迹，是它独特的自然景观。 在这里，天空常年飘舞着缤纷绚烂的极光，如同色彩斑斓的帷幕，为这座冰岛添上了一份梦幻的色彩 介绍 总得去一次吧 不确定再看看\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"article\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"meta\",{\"property\":\"article:author\",\"content\":\"teamwork\"}],[\"meta\",{\"property\":\"article:tag\",\"content\":\"风景\"}],[\"meta\",{\"property\":\"article:published_time\",\"content\":\"2023-04-16T00:00:00.000Z\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"Article\\\",\\\"headline\\\":\\\"看看风景\\\",\\\"image\\\":[\\\"\\\"],\\\"datePublished\\\":\\\"2023-04-16T00:00:00.000Z\\\",\\\"dateModified\\\":null,\\\"author\\\":[{\\\"@type\\\":\\\"Person\\\",\\\"name\\\":\\\"teamwork\\\"}]}\"]]},\"headers\":[{\"level\":2,\"title\":\"冰岛\",\"slug\":\"冰岛\",\"link\":\"#冰岛\",\"children\":[{\"level\":3,\"title\":\"\",\"slug\":\"\",\"link\":\"#\",\"children\":[]},{\"level\":3,\"title\":\"不确定再看看\",\"slug\":\"不确定再看看\",\"link\":\"#不确定再看看\",\"children\":[]}]}],\"readingTime\":{\"minutes\":0.46,\"words\":137},\"filePathRelative\":\"posts/strawberry.md\",\"localizedDate\":\"2023年4月16日\",\"excerpt\":\"<h1> 看看风景</h1>\\n<h2> 冰岛</h2>\\n<h3> </h3>\\n<figure><img src=\\\"/bin3.webp\\\" alt=\\\"\\\" tabindex=\\\"0\\\" loading=\\\"lazy\\\"><figcaption></figcaption></figure>\\n<p>冰岛是一个神秘而美丽的地方</p>\\n<p>从远处望去，仿佛是一块被时间遗忘的冰川巨石，在北极圈内，漫长的白夜和太阳的轨迹，是它独特的自然景观。</p>\\n<p>在这里，天空常年飘舞着缤纷绚烂的极光，如同色彩斑斓的帷幕，为这座冰岛添上了一份梦幻的色彩</p>\\n<h4> 介绍</h4>\\n<p>总得去一次吧</p>\\n<h3> 不确定再看看</h3>\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
