export const data = JSON.parse("{\"key\":\"v-8daa1a0e\",\"path\":\"/\",\"title\":\"博客主页\",\"lang\":\"zh-CN\",\"frontmatter\":{\"home\":true,\"layout\":\"BlogHome\",\"icon\":\"home\",\"title\":\"博客主页\",\"heroImage\":\"/maomao.png\",\"heroText\":\"Team Blog\",\"heroFullScreen\":true,\"tagline\":\"失之淡然 得之坦然\",\"projects\":[{\"icon\":\"/bing.png\",\"name\":\"NewBing\",\"desc\":\"AI智能引擎\",\"link\":\"https://www.bing.com/search?form=MY0291&OCID=MY0291&q=Bing+AI&showconv=1\"},{\"icon\":\"/chatgpt.png\",\"name\":\"chatGPT\",\"desc\":\"不会就找它\",\"link\":\"https://chat.openai.com/\"},{\"icon\":\"/bilibili.png\",\"name\":\"小破站\",\"desc\":\"没事来鬼混\",\"link\":\"https://www.bilibili.com/\"},{\"icon\":\"/youtube.png\",\"name\":\"油管\",\"desc\":\"学习新思想，争做新青年\",\"link\":\"https://www.youtube.com/index\"},{\"icon\":\"/luogu.png\",\"name\":\"洛谷\",\"desc\":\"来刷题吧\",\"link\":\"hhttps://www.luogu.com.cn/\"},{\"icon\":\"/marklogo.png\",\"name\":\"markdown\",\"desc\":\"快来学学\",\"link\":\"https://mdit-plugins.github.io/zh/\"}],\"footer\":\"小组博客  by 任振邦，黄楠，杨林，徐浩，李北川\",\"description\":\"\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小组博客演示\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"博客主页\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"website\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"meta\",{\"property\":\"article:author\",\"content\":\"teamwork\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"WebPage\\\",\\\"name\\\":\\\"博客主页\\\"}\"]]},\"headers\":[],\"readingTime\":{\"minutes\":0.47,\"words\":141},\"filePathRelative\":\"README.md\",\"excerpt\":\"\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
