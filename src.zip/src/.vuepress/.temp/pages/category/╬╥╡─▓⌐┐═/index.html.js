export const data = JSON.parse("{\"key\":\"v-4351d469\",\"path\":\"/category/%E6%88%91%E7%9A%84%E5%8D%9A%E5%AE%A2/\",\"title\":\"我的博客 Category\",\"lang\":\"en-US\",\"frontmatter\":{\"title\":\"我的博客 Category\",\"feed\":false,\"sitemap\":false,\"blog\":{\"type\":\"category\",\"name\":\"我的博客\",\"key\":\"category\"},\"layout\":\"BlogCategory\",\"description\":\"\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/category/%E6%88%91%E7%9A%84%E5%8D%9A%E5%AE%A2/\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"我的博客 Category\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"website\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"en-US\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"WebPage\\\",\\\"name\\\":\\\"我的博客 Category\\\"}\"]]},\"headers\":[],\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
