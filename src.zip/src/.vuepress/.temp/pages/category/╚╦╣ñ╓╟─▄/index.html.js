export const data = JSON.parse("{\"key\":\"v-72c4ce0d\",\"path\":\"/category/%E4%BA%BA%E5%B7%A5%E6%99%BA%E8%83%BD/\",\"title\":\"人工智能 分类\",\"lang\":\"zh-CN\",\"frontmatter\":{\"title\":\"人工智能 分类\",\"index\":false,\"feed\":false,\"sitemap\":false,\"blog\":{\"type\":\"category\",\"name\":\"人工智能\",\"key\":\"category\"},\"layout\":\"BlogCategory\",\"description\":\"\",\"head\":[[\"meta\",{\"property\":\"og:url\",\"content\":\"https://mister-hope.github.io/category/%E4%BA%BA%E5%B7%A5%E6%99%BA%E8%83%BD/\"}],[\"meta\",{\"property\":\"og:site_name\",\"content\":\"小组博客演示\"}],[\"meta\",{\"property\":\"og:title\",\"content\":\"人工智能 分类\"}],[\"meta\",{\"property\":\"og:type\",\"content\":\"website\"}],[\"meta\",{\"property\":\"og:locale\",\"content\":\"zh-CN\"}],[\"meta\",{\"property\":\"article:author\",\"content\":\"teamwork\"}],[\"script\",{\"type\":\"application/ld+json\"},\"{\\\"@context\\\":\\\"https://schema.org\\\",\\\"@type\\\":\\\"WebPage\\\",\\\"name\\\":\\\"人工智能 分类\\\"}\"]]},\"headers\":[],\"readingTime\":{\"minutes\":0,\"words\":0},\"filePathRelative\":null,\"excerpt\":\"\",\"autoDesc\":true}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
