export const typeMap = {"article":{"/":{"path":"/article/","keys":["v-6e19edb7","v-356c5814","v-c88c3ab0","v-cbf5ebee","v-45c1eb86","v-72016c81","v-29070a71","v-5e8d363b","v-e588f34c","v-d2c94e6a","v-af1eac6a","v-5f4c6f58","v-7f41e176","v-2bc6566a","v-24b7c48d","v-711488b9","v-f0ec4556","v-cf5f9d2c","v-08bc01a8","v-2f556660","v-32bf179e","v-5e19bade","v-184f4da6","v-2e3eac9e","v-4e65ec78","v-438ffe52","v-1473bf53"]}},"star":{"/":{"path":"/star/","keys":["v-6e19edb7","v-356c5814","v-c88c3ab0"]}},"timeline":{"/":{"path":"/timeline/","keys":["v-cbf5ebee","v-6e19edb7","v-45c1eb86","v-72016c81","v-29070a71","v-5e8d363b","v-e588f34c","v-356c5814","v-d2c94e6a","v-af1eac6a","v-5f4c6f58","v-7f41e176","v-2bc6566a","v-24b7c48d","v-711488b9","v-f0ec4556","v-cf5f9d2c","v-c88c3ab0","v-08bc01a8","v-2f556660","v-32bf179e","v-5e19bade"]}}};

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept();
  if (__VUE_HMR_RUNTIME__.updateBlogType)
    __VUE_HMR_RUNTIME__.updateBlogType(typeMap);
}

if (import.meta.hot)
  import.meta.hot.accept(({ typeMap }) => {
    __VUE_HMR_RUNTIME__.updateBlogType(typeMap);
  });

