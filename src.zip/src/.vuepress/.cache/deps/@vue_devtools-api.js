import {
  isPerformanceSupported,
  now,
  setupDevtoolsPlugin
} from "./chunk-RFQTXRIF.js";
import "./chunk-OZI5HTJH.js";
export {
  isPerformanceSupported,
  now,
  setupDevtoolsPlugin
};
//# sourceMappingURL=@vue_devtools-api.js.map
